Name: Huy Nguyen
UGA email: hqn34373@uga.edu

to compile: make compile
to run : make run
