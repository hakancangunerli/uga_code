#include <iostream>

#include "Student.h"

using namespace std;

int main(int argc, char* argv[]) {
    Student testStudent;

    testStudent.login("u000545", "pw5904");
}
