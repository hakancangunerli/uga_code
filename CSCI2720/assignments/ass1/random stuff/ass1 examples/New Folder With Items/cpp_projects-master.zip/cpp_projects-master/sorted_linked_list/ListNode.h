#ifndef LISTNODE_H
#define LISTNODE_H
#include "ItemType.h"

using namespace std;

class ListNode {

public:
    ItemType item;
    ListNode *next;
};


#endif
