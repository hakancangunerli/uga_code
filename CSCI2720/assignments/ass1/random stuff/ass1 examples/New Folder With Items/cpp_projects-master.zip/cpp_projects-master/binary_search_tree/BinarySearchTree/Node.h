#ifndef NODE_H
#define NODE_H

using namespace std;

class Node {
public:
    ItemType key;
    Node *left;
    Node *right;
};

#endif
