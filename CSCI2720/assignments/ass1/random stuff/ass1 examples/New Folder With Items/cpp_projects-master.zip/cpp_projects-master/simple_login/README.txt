CSCI 2720 Assignment 1

Seong Cho
sjc73541@uga.edu
811343478

Makefile commands
clean: cleans all .o files
main: creates an exectuable main file
run: run main with instructors.txt and students.txt as file arguments

