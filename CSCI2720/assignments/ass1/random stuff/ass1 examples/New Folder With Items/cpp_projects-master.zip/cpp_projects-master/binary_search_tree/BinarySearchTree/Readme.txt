Seong Cho
811343478
sjc73541@uga.edu

makefile commands:
clean: cleans all object files and temporary files
main: compiles all necessary files and creates an executable main file
run: run main with input.txt as file argument
